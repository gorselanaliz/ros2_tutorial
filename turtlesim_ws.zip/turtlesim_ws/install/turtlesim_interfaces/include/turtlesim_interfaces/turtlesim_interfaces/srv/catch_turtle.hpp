// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TURTLESIM_INTERFACES__SRV__CATCH_TURTLE_HPP_
#define TURTLESIM_INTERFACES__SRV__CATCH_TURTLE_HPP_

#include "turtlesim_interfaces/srv/detail/catch_turtle__struct.hpp"
#include "turtlesim_interfaces/srv/detail/catch_turtle__builder.hpp"
#include "turtlesim_interfaces/srv/detail/catch_turtle__traits.hpp"

#endif  // TURTLESIM_INTERFACES__SRV__CATCH_TURTLE_HPP_
