// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TURTLESIM_INTERFACES__MSG__TURTLE_ARRAY_HPP_
#define TURTLESIM_INTERFACES__MSG__TURTLE_ARRAY_HPP_

#include "turtlesim_interfaces/msg/detail/turtle_array__struct.hpp"
#include "turtlesim_interfaces/msg/detail/turtle_array__builder.hpp"
#include "turtlesim_interfaces/msg/detail/turtle_array__traits.hpp"

#endif  // TURTLESIM_INTERFACES__MSG__TURTLE_ARRAY_HPP_
