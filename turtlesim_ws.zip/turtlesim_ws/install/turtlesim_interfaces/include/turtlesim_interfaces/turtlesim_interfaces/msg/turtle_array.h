// generated from rosidl_generator_c/resource/idl.h.em
// with input from turtlesim_interfaces:msg/TurtleArray.idl
// generated code does not contain a copyright notice

#ifndef TURTLESIM_INTERFACES__MSG__TURTLE_ARRAY_H_
#define TURTLESIM_INTERFACES__MSG__TURTLE_ARRAY_H_

#include "turtlesim_interfaces/msg/detail/turtle_array__struct.h"
#include "turtlesim_interfaces/msg/detail/turtle_array__functions.h"
#include "turtlesim_interfaces/msg/detail/turtle_array__type_support.h"

#endif  // TURTLESIM_INTERFACES__MSG__TURTLE_ARRAY_H_
