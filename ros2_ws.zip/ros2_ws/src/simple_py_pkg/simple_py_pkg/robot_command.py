#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from example_interfaces.msg import String

class RobotCommandNode(Node): 
    def __init__(self):
        super().__init__("robot_command")
        self.declare_parameter("command_to_publish", "Wait for command..") 

        self.command_ = self.get_parameter("command_to_publish").value
        self.command_publisher_ = self.create_publisher(String, "command", 10)
        self.command_timer_ = self.create_timer(1.0, self.publish_command)

        self.get_logger().info("Robot Command has been published !")

    def publish_command(self):
        msg = String()
        msg.data = self.command_
        self.command_publisher_.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = RobotCommandNode() 
    rclpy.spin(node)
    rclpy.shutdown()


if __name__ == "__main__":
    main()